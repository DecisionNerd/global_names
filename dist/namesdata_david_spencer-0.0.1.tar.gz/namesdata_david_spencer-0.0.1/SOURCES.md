The names included in this database were collected from a variety of web sites. Below are the credits for the lists that have attributions. So far as I know, none of these databases or lists are copyrighted.

### For Last Names:
- **Basque**: Bildu Bizkaia (http://euskalikurra.blogspot.com/) and ListGene (http://listgene.com/antzinako/)
- **Chinese**: Ron Young, Alphabetical Index of Chinese Surnames (http://freepages.family.rootsweb.ancestry.com/~chinesesurname/atoz.html)
- **Czech**: Mike Campbell, Behind the Name: Czech Surnames (http://surnames.behindthename.com/names/usage/czech)
- **German**: The Namenforschung project (http://www.namenforschung.net/dfa/downloads.html)
- **Spanish**: The National Institute of Statistics (INE) (http://www.ine.es/daco/daco42/nombyapel/nombyapel.htm)
- **French**: The nom-famille website (http://www.nom-famille.com)
- **Greek**: Dimitri's Surname Database (http://www.dimitri.8m.com/surnames.html)
- **Indian**: Kate Monk, Kate Monk's Onomastikon (http://www.gaminggeeks.org/Resources/KateMonk/)
- **Irish**: Mike Campbell, Behind the Name: Irish Surnames (http://surnames.behindthename.com/names/usage/irish)
- **Italian**: alfemminile.com, I cognomi più diffusi italiani (http://cognome.alfemminile.com/w/cognomi/cognome-lista.html)
- **Korean**: Meet My Last Name (http://meetmylastname.com/prd/articles/36/)
- **Dutch**: Mike Campbell, Behind the Names: Dutch surnames (http://surnames.behindthename.com/names/usage/dutch)
- **Polish**: Polish Texans (http://www.polish-texans.com/genealogy/surnames-all.php?tree=PT)
- **Portuguese**: Fernando Candado, Lista de sobrenomes portugueses (http://www.fernandocandido.com/portgen/portuguese-names/names.html)
- **Russian**: Michael Birukoff, All Russia Family Tree. Surnames list. (http://www.vgd.ru/ENGLISH/a.htm)
- **UK**: sofeminine.co.uk, List of the most common surnames (http://surname.sofeminine.co.uk/w/surnames/most-common-surnames-in-great-britain.html)
- **US**: Princeton University, Intro CS class dataset (http://www.cs.princeton.edu/introcs/data/surnames.csv)

### For First Names:
- **US**: US Census Bureau (http://www.census.gov/genealogy/www/data/1990surnames/dist.male.first) and Quiet Affiliate (http://www.quietaffiliate.com/free-first-name-and-last-name-databases-csv-and-sql)
- **Spain**: INE (National Statistics Institute) (http://www.ine.es/tnombres/formGeneralresult.do)
